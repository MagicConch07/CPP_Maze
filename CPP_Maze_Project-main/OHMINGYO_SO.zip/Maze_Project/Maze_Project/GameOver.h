#pragma once
#include<fcntl.h>
#include<corecrt_io.h>
#include"define.h"
#include "TitleScene.h"

void GameOverRender();
bool GameOverScene();
MENU GOMenuRender();