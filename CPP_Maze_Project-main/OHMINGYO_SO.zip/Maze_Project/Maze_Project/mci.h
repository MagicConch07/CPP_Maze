#pragma once
void PlayBgm(LPCWSTR _soundname, int _volume);
void PlayEffect(LPCWSTR _soundname);